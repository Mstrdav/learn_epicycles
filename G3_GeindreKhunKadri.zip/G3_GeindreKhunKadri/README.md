# G3_GeindreKhunKadri
Projet du bac blanc pour l'ISN : un site axé autours du théorème des 4 couleurs.

Il faut lancer index.html et ensuite laissez vous guider par les flots du site ! (Ne vous perdez pas trop non plus...)

Bonne "correction" et bon jeu !!!

PS: Le site est disponible en ligne ! (à l'adresse suivante) 

http://4couleurs.pirez.me/
